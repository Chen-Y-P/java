import AvatarList from './List'
import './index.less'

export default AvatarList
