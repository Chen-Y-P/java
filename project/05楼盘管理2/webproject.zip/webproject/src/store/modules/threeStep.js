const threeStep = {
    state: {
        cellMessage: []
    },
    mutations: {
        SET_TITLE(state, payload) {
            state.cellMessage = payload.cellMessage
        }
    },
    actions: {

    },
    getters: {

    }
}

export default threeStep
